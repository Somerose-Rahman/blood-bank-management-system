/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Blood__Bank;

import java.sql.*;

/**
 *
 * @author lenovo
 */
public class DonorInfo {
    
    private String  name;
    private String bloodGroup;
    private String lastDonationDate;
    private int noOfDonation;
    private String gender;
    private String location;
    private String phoneNo;
    private String pass;
    
    /*
    public DonorInfo(String  name,String bloodGroup,String lastDonationDate,int noOfDonation,String gender,String location,String phoneNo,String password)
    {
        this.name=name;
        this.bloodGroup=bloodGroup;
        this.lastDonationDate=lastDonationDate;
        this.noOfDonation=noOfDonation;
        this.gender=gender;
        this.location=location;
        this.phoneNo=phoneNo;
        this.password=password;
    }
   */
    
    
    void connect() throws SQLException 
    {
        Connection conn = null;
        try {
     
            String url = "jdbc:sqlite:C:\\Users\\lenovo\\Documents\\NetBeansProjects\\Blood_Bank\\Bloodbank.sqlite";
        
            conn = DriverManager.getConnection(url);
            
            System.out.println("Connection to SQLite has been established.");
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
             System.out.println("connection problem");
            
        } 
    }
    
    public String getname()
    {
        return  name;
    }
    public void setname(String name)
    {
        this.name=name;
    }
     public String getbloodGroup()
    {
        return  bloodGroup;
    }
    public void setbloodGroup(String bloodGroup)
    {
        this.bloodGroup=bloodGroup;
    }
    
    public String getlastDonationDate()
    {
        return lastDonationDate ;
    }
    public void setlastDonationDate(String lastDonationDate)
    {
        this.lastDonationDate=lastDonationDate;
    }
    
    public int getnoOfDonation()
    {
        return  noOfDonation;
    }
    public void setnoOfDonation(int noOfDonation)
    {
        this.noOfDonation=noOfDonation;
    }
    
    public String getgender()
    {
        return  gender;
    }
    public void setgender(String gender)
    {
        this.gender=gender;
    }
    
    public String getlocation()
    {
        return  location;
    }
    public void setlocation(String location)
    {
        this.location=location;
    }
    
    public String getphoneNo()
    {
        return phoneNo;
    }
    public void setphoneNo(String phoneNo)
    {
        this.phoneNo=phoneNo;
    }
    
    public String getpass()
    {
        return  pass;
    }
    public void setpass(String pass)
    {
        this.pass=pass;
    }
    
}
